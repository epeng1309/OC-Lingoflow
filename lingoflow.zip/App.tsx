import React, { useState, useEffect } from 'react';
import { Screen, Word } from './types';
import { Dashboard } from './screens/Dashboard';
import { Library } from './screens/Library';
import { DeckView } from './screens/DeckView';
import { FlashcardSession } from './screens/FlashcardSession';
import { Stats } from './screens/Stats';
import { SpellingPractice } from './screens/SpellingPractice';
import { WeakWords } from './screens/WeakWords';
import { Settings } from './screens/Settings';
import { WORD_LIST } from './constants';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.DASHBOARD);
  const [words, setWords] = useState<Word[]>(WORD_LIST);
  
  // Check system preference initially
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Apply theme class to html element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleAddWords = (newWords: Word[]) => {
    setWords((prev) => [...prev, ...newWords]);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.DASHBOARD:
        return <Dashboard onNavigate={setCurrentScreen} />;
      case Screen.LIBRARY:
        return <Library onNavigate={setCurrentScreen} />;
      case Screen.DECK_VIEW:
        return (
          <DeckView 
            onNavigate={setCurrentScreen} 
            words={words} 
            onAddWords={handleAddWords} 
          />
        );
      case Screen.FLASHCARD:
        return (
          <FlashcardSession 
            onNavigate={setCurrentScreen} 
            words={words} 
          />
        );
      case Screen.STATS:
        return <Stats onNavigate={setCurrentScreen} />;
      case Screen.SPELLING:
        return (
          <SpellingPractice 
            onNavigate={setCurrentScreen} 
            words={words} 
          />
        );
      case Screen.WEAK_WORDS:
        return <WeakWords onNavigate={setCurrentScreen} />;
      case Screen.SETTINGS:
        return (
          <Settings 
            onNavigate={setCurrentScreen} 
            isDarkMode={isDarkMode}
            onToggleTheme={() => setIsDarkMode(!isDarkMode)}
          />
        );
      default:
        return <Dashboard onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <div className="w-full h-full min-h-screen bg-neutral-100 dark:bg-neutral-900 flex justify-center">
      {/* Wrapper to simulate mobile view on desktop if opened there */}
      <div className="w-full max-w-md bg-background-light dark:bg-background-dark min-h-screen shadow-2xl relative">
        {renderScreen()}
      </div>
    </div>
  );
};

export default App;
