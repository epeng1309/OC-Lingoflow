export enum Screen {
  DASHBOARD = 'DASHBOARD',
  LIBRARY = 'LIBRARY',
  DECK_VIEW = 'DECK_VIEW',
  FLASHCARD = 'FLASHCARD',
  SPELLING = 'SPELLING',
  STATS = 'STATS',
  WEAK_WORDS = 'WEAK_WORDS',
  SETTINGS = 'SETTINGS',
}

export interface Deck {
  id: string;
  title: string;
  subtitle: string;
  count: number;
  progress: number;
  fromLang: string;
  toLang: string;
  colorClass: string;
  icon: string;
  isNew?: boolean;
  isReview?: boolean;
}

export interface Word {
  id: string;
  original: string;
  translated: string;
  type: string;
  audio?: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  colorBg: string;
  colorText: string;
  locked?: boolean;
}
