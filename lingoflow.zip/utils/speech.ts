export const speak = (text: string, lang: string = 'de-DE') => {
  if (!window.speechSynthesis) {
    console.warn("Browser does not support speech synthesis");
    return;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang;
  utterance.rate = 0.9; // Slightly slower for learning
  
  // Try to find a specific voice for the language if available
  const voices = window.speechSynthesis.getVoices();
  const voice = voices.find(v => v.lang.includes(lang));
  if (voice) {
    utterance.voice = voice;
  }

  window.speechSynthesis.speak(utterance);
};
