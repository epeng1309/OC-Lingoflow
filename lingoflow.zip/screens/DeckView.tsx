import React, { useState, useRef, useMemo } from 'react';
import { Screen, Word } from '../types';
import { Icon } from '../components/Icon';
import { speak } from '../utils/speech';

interface DeckViewProps {
  onNavigate: (screen: Screen) => void;
  words: Word[];
  onAddWords: (newWords: Word[]) => void;
}

export const DeckView: React.FC<DeckViewProps> = ({ onNavigate, words, onAddWords }) => {
  const [showImport, setShowImport] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<string[][]>([]);
  const [termCol, setTermCol] = useState(0);
  const [defCol, setDefCol] = useState(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSpeak = (e: React.MouseEvent, text: string) => {
    e.stopPropagation();
    speak(text);
  };

  const handleFileClick = () => {
    fileInputRef.current?.click();
  };

  // Robust CSV Parser handling quotes and newlines
  const parseCSV = (content: string): string[][] => {
    const arr: string[][] = [];
    let quote = false;
    let row = 0, col = 0;
    
    for (let c = 0; c < content.length; c++) {
      let cc = content[c], nc = content[c+1];
      arr[row] = arr[row] || [];
      arr[row][col] = arr[row][col] || '';

      if (cc == '"' && quote && nc == '"') { arr[row][col] += cc; ++c; continue; }
      if (cc == '"') { quote = !quote; continue; }
      if (cc == ',' && !quote) { ++col; continue; }
      if (cc == '\r' && nc == '\n' && !quote) { ++row; col = 0; ++c; continue; }
      if (cc == '\n' && !quote) { ++row; col = 0; continue; }
      if (cc == '\r' && !quote) { ++row; col = 0; continue; }

      arr[row][col] += cc;
    }
    // Filter out completely empty rows
    return arr.filter(r => r.length > 0 && r.some(cell => cell.trim() !== ''));
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        const data = parseCSV(text);
        setParsedData(data);
        
        // Smart default: If 4 columns (Google Translate), likely 2 (Source Text) and 3 (Target Text)
        if (data.length > 0 && data[0].length >= 4) {
          setTermCol(2);
          setDefCol(3);
        } else {
          setTermCol(0);
          setDefCol(1);
        }
      };
      reader.readAsText(file);
    }
  };

  const handleImport = () => {
    if (!selectedFile || parsedData.length === 0) return;

    const newWords: Word[] = parsedData.map((row, index) => {
        // Safe access
        const original = row[termCol] || '';
        const translated = row[defCol] || '';
        
        if (!original.trim() && !translated.trim()) return null;

        return {
            id: Date.now().toString() + index,
            original: original.trim(),
            translated: translated.trim(),
            type: 'Term', // Default type
            audio: true
        };
    }).filter((w): w is Word => w !== null);

    if (newWords.length > 0) {
      onAddWords(newWords);
      setShowImport(false);
      resetImportState();
      alert(`Successfully imported ${newWords.length} words!`);
    } else {
      alert("No valid words found. Please check column selection.");
    }
  };

  const resetImportState = () => {
    setSelectedFile(null);
    setParsedData([]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const previewData = useMemo(() => {
    return parsedData.slice(0, 3).map(row => ({
      term: row[termCol] || '',
      def: row[defCol] || ''
    }));
  }, [parsedData, termCol, defCol]);

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col max-w-md mx-auto bg-background-light dark:bg-background-dark shadow-2xl overflow-hidden font-display">
      {/* Navigation Bar */}
      <header className="sticky top-0 z-20 bg-surface-light dark:bg-surface-dark/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="flex items-center justify-between px-4 h-14">
          <button 
            onClick={() => onNavigate(Screen.LIBRARY)}
            className="flex items-center justify-center w-10 h-10 -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-primary"
          >
            <Icon name="chevron_left" size={28} />
          </button>
          <h1 className="flex-1 text-center text-lg font-bold tracking-tight truncate px-2 text-slate-900 dark:text-white">
            B1 Vocabulary
          </h1>
          <button 
            className="flex items-center justify-center w-10 h-10 -mr-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-primary"
            onClick={() => setShowImport(true)}
          >
            <Icon name="file_upload" size={24} />
          </button>
        </div>
        {/* Search Bar Area */}
        <div className="px-4 pb-3 pt-1">
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400 group-focus-within:text-primary transition-colors">
              <Icon name="search" size={20} />
            </div>
            <input 
              className="block w-full p-2.5 pl-10 text-sm bg-slate-100 dark:bg-slate-800 border-none rounded-lg focus:ring-2 focus:ring-primary focus:bg-white dark:focus:bg-slate-900 placeholder-slate-400 dark:placeholder-slate-500 transition-all shadow-sm text-slate-900 dark:text-white" 
              placeholder="Search words..." 
              type="text"
            />
          </div>
        </div>
      </header>

      {/* Main Content: Word List */}
      <main className="flex-1 overflow-y-auto no-scrollbar pb-24">
        {/* List Header / Stats */}
        <div className="px-4 py-3 flex justify-between items-center text-xs font-medium text-slate-500 uppercase tracking-wider">
          <span>{words.length} Words</span>
          <span className="flex items-center gap-1 cursor-pointer hover:text-primary transition-colors">
            Sort by
            <Icon name="sort" size={16} />
          </span>
        </div>
        {/* List Items */}
        <div className="space-y-[1px] bg-slate-200 dark:bg-slate-800/50">
          {words.map((word) => (
            <div 
              key={word.id}
              onClick={() => onNavigate(Screen.FLASHCARD)}
              className="flex items-center justify-between p-4 bg-surface-light dark:bg-surface-dark active:bg-slate-50 dark:active:bg-slate-800 transition-colors cursor-pointer group"
            >
              <div className="flex flex-col gap-0.5">
                <p className="text-base font-semibold text-slate-900 dark:text-white line-clamp-1">{word.original}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-1">{word.translated}</p>
              </div>
              <button 
                className="w-10 h-10 shrink-0 flex items-center justify-center rounded-full text-primary hover:bg-primary/10 active:scale-95 transition-all"
                onClick={(e) => handleSpeak(e, word.original)}
              >
                <Icon name="volume_up" />
              </button>
            </div>
          ))}
        </div>
        <div className="h-6"></div>
      </main>

      {/* Floating Action Button */}
      <div className="absolute bottom-6 right-4 z-10">
        <button 
          onClick={() => onNavigate(Screen.FLASHCARD)}
          className="flex items-center justify-center w-14 h-14 bg-primary text-white rounded-full shadow-lg hover:bg-primary/90 active:scale-95 transition-all focus:outline-none focus:ring-4 focus:ring-primary/30"
        >
          <Icon name="play_arrow" size={28} />
        </button>
      </div>

      {/* Import Modal (Bottom Sheet) */}
      <div className={`absolute inset-0 z-30 flex flex-col justify-end transition-transform duration-300 ease-in-out ${showImport ? 'translate-y-0' : 'translate-y-full pointer-events-none'}`}>
        {/* Backdrop */}
        <div 
          className={`absolute inset-0 bg-black/40 backdrop-blur-sm cursor-pointer transition-opacity duration-300 ${showImport ? 'opacity-100' : 'opacity-0'}`} 
          onClick={() => { setShowImport(false); resetImportState(); }}
        ></div>
        
        {/* Sheet Content */}
        <div className="relative w-full bg-surface-light dark:bg-surface-dark rounded-t-2xl shadow-2xl pointer-events-auto max-h-[90vh] overflow-y-auto flex flex-col">
          {/* Handle */}
          <div className="w-full flex justify-center pt-3 pb-1" onClick={() => { setShowImport(false); resetImportState(); }}>
            <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-600 rounded-full"></div>
          </div>
          
          <div className="p-6 space-y-6 flex-1 overflow-y-auto">
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3">
                <Icon name="table_view" className="text-primary" size={28} />
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Import Vocabulary</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Select a CSV file to add words to this deck.</p>
            </div>
            
            {/* File Selection */}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".csv"
              onChange={handleFileChange}
            />
            
            {!selectedFile ? (
              <div 
                className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer gap-3"
                onClick={handleFileClick}
              >
                <Icon name="upload_file" className="text-slate-400" size={40} />
                <div className="text-center">
                   <p className="text-base font-semibold text-slate-700 dark:text-slate-200">Tap to upload CSV</p>
                   <p className="text-xs text-slate-400 mt-1">Google Translate exports supported</p>
                </div>
              </div>
            ) : (
               <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                  {/* File Info */}
                  <div className="flex items-center justify-between bg-slate-100 dark:bg-slate-800 p-3 rounded-lg">
                    <div className="flex items-center gap-3 overflow-hidden">
                       <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded text-green-600">
                          <Icon name="description" size={20} />
                       </div>
                       <div className="flex flex-col overflow-hidden">
                          <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">{selectedFile.name}</span>
                          <span className="text-xs text-slate-500">{parsedData.length} rows found</span>
                       </div>
                    </div>
                    <button onClick={resetImportState} className="text-slate-400 hover:text-red-500 p-2">
                       <Icon name="close" size={20} />
                    </button>
                  </div>

                  {/* Column Mapping */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                       <h3 className="text-sm font-bold text-slate-900 dark:text-white">Map Columns</h3>
                       <span className="text-xs text-slate-500">Match your CSV columns</span>
                    </div>
                    
                    {parsedData.length > 0 && (
                      <div className="grid gap-4">
                        {/* Term Mapping */}
                        <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 block">
                              Original Word (Front)
                            </label>
                            <div className="relative">
                              <select 
                                value={termCol}
                                onChange={(e) => setTermCol(Number(e.target.value))}
                                className="w-full appearance-none bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg py-2.5 pl-3 pr-10 text-sm focus:ring-2 focus:ring-primary outline-none text-slate-900 dark:text-white"
                              >
                                {parsedData[0].map((_, idx) => (
                                  <option key={idx} value={idx}>
                                    Column {idx + 1} (e.g. {parsedData[0][idx]?.substring(0, 15)}...)
                                  </option>
                                ))}
                              </select>
                              <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none text-slate-500">
                                <Icon name="expand_more" size={20} />
                              </div>
                            </div>
                        </div>

                        {/* Definition Mapping */}
                        <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 block">
                              Translation (Back)
                            </label>
                            <div className="relative">
                              <select 
                                value={defCol}
                                onChange={(e) => setDefCol(Number(e.target.value))}
                                className="w-full appearance-none bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg py-2.5 pl-3 pr-10 text-sm focus:ring-2 focus:ring-primary outline-none text-slate-900 dark:text-white"
                              >
                                {parsedData[0].map((_, idx) => (
                                  <option key={idx} value={idx}>
                                    Column {idx + 1} (e.g. {parsedData[0][idx]?.substring(0, 15)}...)
                                  </option>
                                ))}
                              </select>
                              <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none text-slate-500">
                                <Icon name="expand_more" size={20} />
                              </div>
                            </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Preview Section */}
                  <div className="space-y-2">
                     <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Preview (First 3 Cards)</h3>
                     <div className="space-y-2">
                        {previewData.map((row, i) => (
                           <div key={i} className="flex items-center gap-3 p-2 rounded bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                              <span className="text-xs font-mono text-slate-400 w-4">{i+1}</span>
                              <div className="flex-1 grid grid-cols-2 gap-2">
                                 <p className="text-sm font-medium truncate">{row.term}</p>
                                 <p className="text-sm text-slate-500 truncate">{row.def}</p>
                              </div>
                           </div>
                        ))}
                     </div>
                  </div>
               </div>
            )}

            {/* Actions */}
            <div className="pt-2 flex gap-3">
              <button 
                className="flex-1 py-3 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                onClick={() => {
                  setShowImport(false);
                  resetImportState();
                }}
              >
                Cancel
              </button>
              <button 
                className={`flex-1 py-3 px-4 rounded-xl text-white font-semibold shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 ${selectedFile ? 'bg-primary hover:bg-primary/90 shadow-primary/20' : 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed'}`}
                onClick={handleImport}
                disabled={!selectedFile}
              >
                <span>Import Words</span>
                <Icon name="arrow_forward" size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
