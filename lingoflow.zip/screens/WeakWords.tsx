import React from 'react';
import { Screen } from '../types';
import { Icon } from '../components/Icon';
import { speak } from '../utils/speech';

interface WeakWordsProps {
  onNavigate: (screen: Screen) => void;
}

export const WeakWords: React.FC<WeakWordsProps> = ({ onNavigate }) => {
  const handleSpeak = (text: string) => {
    speak(text);
  };

  return (
    <div className="font-sans bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen flex flex-col overflow-x-hidden antialiased transition-colors duration-200 pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md transition-colors">
        <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
          <button 
            onClick={() => onNavigate(Screen.DASHBOARD)}
            className="size-12 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-700 dark:text-slate-200"
          >
            <Icon name="arrow_back" />
          </button>
          <h1 className="text-[22px] font-normal text-slate-900 dark:text-white">Weak Words</h1>
          <button className="h-10 px-4 flex items-center justify-center rounded-full bg-primary-container text-on-primary-container hover:brightness-95 transition-colors">
            <span className="text-sm font-medium">Review All</span>
          </button>
        </div>
      </header>

      <main className="flex-1 w-full max-w-md mx-auto px-4 pb-4">
        {/* Filters */}
        <div className="sticky top-16 z-40 bg-background-light dark:bg-background-dark py-2 -mx-4 px-4 mb-2 transition-colors">
          <div className="flex gap-2 overflow-x-auto no-scrollbar items-center py-2">
            <button className="flex shrink-0 items-center justify-center gap-x-2 rounded-lg bg-[#DBE4E6] dark:bg-[#3F484A] py-1.5 px-4 transition-colors active:scale-95 border border-transparent">
              <Icon name="check" size={18} className="text-slate-700 dark:text-slate-200" />
              <span className="text-slate-900 dark:text-slate-100 text-sm font-medium">Date Added</span>
            </button>
            <button className="flex shrink-0 items-center justify-center gap-x-2 rounded-lg border border-outline-variant bg-transparent py-1.5 px-4 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50">
              <span className="text-slate-600 dark:text-slate-300 text-sm font-medium">Confidence</span>
              <Icon name="arrow_drop_down" size={18} className="text-slate-500" />
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {/* Card 1 */}
          <article className="group relative rounded-xl bg-surface-container dark:bg-card-dark transition-all hover:bg-surface-container-high dark:hover:bg-[#2A2D2E]">
            <div className="flex items-start justify-between p-4">
              <div className="flex-1 pr-3">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-normal text-slate-900 dark:text-white leading-tight">Schadenfreude</h3>
                  <button 
                    className="text-primary hover:bg-primary/10 transition-colors flex items-center justify-center size-8 rounded-full"
                    onClick={() => handleSpeak("Schadenfreude")}
                  >
                    <Icon name="volume_up" size={20} />
                  </button>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal mb-3">Joy at others' misfortune</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-error-container text-on-error-container">
                    <Icon name="warning" size={14} />
                    <span className="text-xs font-medium">Hard</span>
                  </div>
                  <span className="text-xs text-slate-400">2d ago</span>
                </div>
              </div>
              <div className="flex flex-col items-end justify-center h-full self-center pl-2">
                <button className="flex cursor-pointer items-center justify-center rounded-full h-10 px-6 bg-primary hover:bg-primary-dark text-white text-sm font-medium shadow-none hover:shadow-elevation-1 transition-all active:scale-95">
                  Review
                </button>
              </div>
            </div>
          </article>

          {/* Card 2 */}
          <article className="group relative rounded-xl bg-surface-container dark:bg-card-dark transition-all hover:bg-surface-container-high dark:hover:bg-[#2A2D2E]">
            <div className="flex items-start justify-between p-4">
              <div className="flex-1 pr-3">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-normal text-slate-900 dark:text-white leading-tight">Naturwissenschaft</h3>
                  <button 
                    className="text-primary hover:bg-primary/10 transition-colors flex items-center justify-center size-8 rounded-full"
                    onClick={() => handleSpeak("Naturwissenschaft")}
                  >
                    <Icon name="volume_up" size={20} />
                  </button>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal mb-3">Natural Science</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-primary-container text-on-primary-container">
                    <Icon name="refresh" size={14} />
                    <span className="text-xs font-medium">Review</span>
                  </div>
                  <span className="text-xs text-slate-400">3d ago</span>
                </div>
              </div>
              <div className="flex flex-col items-end justify-center h-full self-center pl-2">
                <button className="flex cursor-pointer items-center justify-center rounded-full h-10 px-6 bg-transparent border border-outline-variant hover:bg-primary/5 text-primary text-sm font-medium transition-all active:scale-95">
                  Review
                </button>
              </div>
            </div>
          </article>

          {/* Card 3 */}
          <article className="group relative rounded-xl bg-surface-container dark:bg-card-dark transition-all hover:bg-surface-container-high dark:hover:bg-[#2A2D2E]">
            <div className="flex items-start justify-between p-4">
              <div className="flex-1 pr-3">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-normal text-slate-900 dark:text-white leading-tight">Sehenswürdigkeiten</h3>
                  <button 
                    className="text-primary hover:bg-primary/10 transition-colors flex items-center justify-center size-8 rounded-full"
                    onClick={() => handleSpeak("Sehenswürdigkeiten")}
                  >
                    <Icon name="volume_up" size={20} />
                  </button>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal mb-3">Sights / Attractions</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-primary-container text-on-primary-container">
                    <Icon name="refresh" size={14} />
                    <span className="text-xs font-medium">Review</span>
                  </div>
                  <span className="text-xs text-slate-400">5d ago</span>
                </div>
              </div>
              <div className="flex flex-col items-end justify-center h-full self-center pl-2">
                <button className="flex cursor-pointer items-center justify-center rounded-full h-10 px-6 bg-transparent border border-outline-variant hover:bg-primary/5 text-primary text-sm font-medium transition-all active:scale-95">
                  Review
                </button>
              </div>
            </div>
          </article>

          {/* Card 4 */}
          <article className="group relative rounded-xl bg-surface-container dark:bg-card-dark transition-all hover:bg-surface-container-high dark:hover:bg-[#2A2D2E]">
            <div className="flex items-start justify-between p-4">
              <div className="flex-1 pr-3">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-normal text-slate-900 dark:text-white leading-tight">Eichhörnchen</h3>
                  <button 
                    className="text-primary hover:bg-primary/10 transition-colors flex items-center justify-center size-8 rounded-full"
                    onClick={() => handleSpeak("Eichhörnchen")}
                  >
                    <Icon name="volume_up" size={20} />
                  </button>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal mb-3">Squirrel</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-error-container text-on-error-container">
                    <Icon name="dangerous" size={14} />
                    <span className="text-xs font-medium">Critical</span>
                  </div>
                  <span className="text-xs text-slate-400">1w ago</span>
                </div>
              </div>
              <div className="flex flex-col items-end justify-center h-full self-center pl-2">
                <button className="flex cursor-pointer items-center justify-center rounded-full h-10 px-6 bg-primary hover:bg-primary-dark text-white text-sm font-medium shadow-none hover:shadow-elevation-1 transition-all active:scale-95">
                  Review
                </button>
              </div>
            </div>
          </article>
        </div>

        <div className="mt-8 text-center pb-4">
          <p className="text-xs text-slate-400 dark:text-slate-600 font-medium">Showing 4 of 12 weak words</p>
        </div>
      </main>

      {/* Unique Bottom Nav for Weak Words screen */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background-light dark:bg-background-dark border-t border-slate-200 dark:border-slate-800 pb-safe">
        <div className="max-w-md mx-auto h-20 px-4 flex justify-between items-center">
          <button onClick={() => onNavigate(Screen.DASHBOARD)} className="flex-1 flex flex-col items-center justify-center gap-1 group">
            <div className="py-1 px-5 rounded-full group-hover:bg-slate-100 dark:group-hover:bg-slate-800 transition-colors">
              <Icon name="dashboard" className="text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200" />
            </div>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200">Home</span>
          </button>
          <button onClick={() => onNavigate(Screen.LIBRARY)} className="flex-1 flex flex-col items-center justify-center gap-1 group">
            <div className="py-1 px-5 rounded-full group-hover:bg-slate-100 dark:group-hover:bg-slate-800 transition-colors">
              <Icon name="style" className="text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200" />
            </div>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200">Library</span>
          </button>
          <button className="flex-1 flex flex-col items-center justify-center gap-1">
            <div className="py-1 px-5 rounded-full bg-primary-container">
              <Icon name="flag" className="text-on-primary-container" filled />
            </div>
            <span className="text-xs font-bold text-on-primary-container dark:text-slate-200">Weak</span>
          </button>
          <button 
             onClick={() => onNavigate(Screen.SETTINGS)}
             className="flex-1 flex flex-col items-center justify-center gap-1 group"
          >
            <div className="py-1 px-5 rounded-full group-hover:bg-slate-100 dark:group-hover:bg-slate-800 transition-colors">
              <Icon name="person" className="text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200" />
            </div>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
};
