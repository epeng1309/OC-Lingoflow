import React, { useState } from 'react';
import { Screen } from '../types';
import { Icon } from '../components/Icon';

interface SettingsProps {
  onNavigate: (screen: Screen) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

export const Settings: React.FC<SettingsProps> = ({ onNavigate, isDarkMode, onToggleTheme }) => {
  const [notifications, setNotifications] = useState(true);
  const [profileName, setProfileName] = useState("Alex");
  const [sourceLang, setSourceLang] = useState("English");
  const [learnLang, setLearnLang] = useState("German");

  const cycleLanguage = (current: string, setter: (s: string) => void, options: string[]) => {
    const idx = options.indexOf(current);
    const next = options[(idx + 1) % options.length];
    setter(next);
  };

  const handleEditProfile = () => {
    const newName = prompt("Enter new profile name:", profileName);
    if (newName) setProfileName(newName);
  };

  const settingsGroups = [
    {
      title: "Account",
      items: [
        { 
          icon: "person", 
          label: "Profile", 
          value: profileName, 
          action: handleEditProfile 
        },
        { 
          icon: "email", 
          label: "Email", 
          value: "alex@example.com", 
          action: () => alert("Email change not supported in demo.") 
        },
        { 
          icon: "workspace_premium", 
          label: "Subscription", 
          value: "Free Plan",
          action: () => alert("Upgrade to Premium for offline access!")
        }
      ]
    },
    {
      title: "Preferences",
      items: [
        { 
          icon: "language", 
          label: "Source Language", 
          value: sourceLang, 
          action: () => cycleLanguage(sourceLang, setSourceLang, ["English", "Spanish", "French", "Chinese"]) 
        },
        { 
          icon: "translate", 
          label: "Learning Language", 
          value: learnLang,
          action: () => cycleLanguage(learnLang, setLearnLang, ["German", "Italian", "Japanese", "Portuguese"])
        },
        { 
          icon: "notifications", 
          label: "Notifications", 
          toggle: true, 
          checked: notifications,
          action: () => setNotifications(!notifications)
        },
        { 
          icon: "dark_mode", 
          label: "Dark Mode", 
          toggle: true, 
          checked: isDarkMode,
          action: onToggleTheme
        }
      ]
    },
    {
      title: "Support",
      items: [
        { icon: "help", label: "Help Center", action: () => window.open('https://google.com', '_blank') },
        { icon: "feedback", label: "Send Feedback", action: () => window.location.href = "mailto:support@lingoflow.com" },
        { icon: "info", label: "About LingoFlow", value: "v1.0.0", action: () => alert("LingoFlow v1.0.0\nBuilt with React & Tailwind") }
      ]
    }
  ];

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-white pb-safe transition-colors duration-200">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-surface-light/95 dark:bg-surface-dark/95 backdrop-blur-md px-4 h-16 flex items-center gap-4 border-b border-slate-200 dark:border-slate-800">
        <button 
          onClick={() => onNavigate(Screen.DASHBOARD)}
          className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Icon name="arrow_back" />
        </button>
        <h1 className="text-xl font-bold">Settings</h1>
      </header>

      <main className="flex-1 overflow-y-auto no-scrollbar p-4 gap-6 flex flex-col">
        {settingsGroups.map((group, idx) => (
          <section key={idx}>
            <h2 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 px-2">
              {group.title}
            </h2>
            <div className="bg-surface-light dark:bg-surface-dark rounded-2xl overflow-hidden shadow-sm border border-slate-100 dark:border-slate-700">
              {group.items.map((item, itemIdx) => (
                <div 
                  key={itemIdx}
                  onClick={item.action}
                  className={`flex items-center justify-between p-4 active:bg-slate-50 dark:active:bg-slate-800 transition-colors cursor-pointer ${
                    itemIdx !== group.items.length - 1 ? 'border-b border-slate-100 dark:border-slate-700/50' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      <Icon name={item.icon} size={20} />
                    </div>
                    <span className="font-medium">{item.label}</span>
                  </div>
                  
                  {item.toggle !== undefined ? (
                    <div className={`w-11 h-6 rounded-full relative transition-colors ${item.checked ? 'bg-primary' : 'bg-slate-300 dark:bg-slate-600'}`}>
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-200 ${item.checked ? 'left-6' : 'left-1'}`}></div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500">
                      {item.value && <span className="text-sm">{item.value}</span>}
                      <Icon name="chevron_right" size={20} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        ))}

        <button 
            onClick={() => {
                if(confirm("Are you sure you want to log out?")) {
                    onNavigate(Screen.DASHBOARD);
                    alert("Logged out successfully.");
                }
            }}
            className="w-full py-4 mt-4 text-red-500 font-bold bg-red-50 dark:bg-red-900/20 rounded-xl hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors"
        >
          Log Out
        </button>
      </main>
    </div>
  );
};
