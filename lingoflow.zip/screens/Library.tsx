import React from 'react';
import { Screen } from '../types';
import { Icon } from '../components/Icon';
import { DECKS } from '../constants';
import { BottomNav } from '../components/BottomNav';

interface LibraryProps {
  onNavigate: (screen: Screen) => void;
}

export const Library: React.FC<LibraryProps> = ({ onNavigate }) => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-md mx-auto bg-background-light dark:bg-background-dark shadow-2xl overflow-hidden pb-24 font-display">
      {/* Top Status Bar Simulation */}
      <div className="h-8 w-full bg-background-light dark:bg-background-dark sticky top-0 z-20"></div>
      
      {/* Top App Bar */}
      <div className="flex items-center px-6 py-4 justify-between bg-background-light dark:bg-background-dark sticky top-8 z-10">
        <h2 className="text-slate-900 dark:text-white text-3xl font-bold leading-tight tracking-tight flex-1">My Decks</h2>
        <div className="flex items-center justify-end">
          <button 
            className="flex items-center justify-center rounded-full h-10 w-10 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            onClick={() => onNavigate(Screen.SETTINGS)}
          >
            <Icon name="settings" size={24} />
          </button>
        </div>
      </div>

      {/* Action Section: Import CSV */}
      <div className="px-6 py-2">
        <button 
          className="flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl h-12 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm text-primary gap-2 text-sm font-bold leading-normal tracking-wide hover:bg-slate-50 dark:hover:bg-slate-750 transition-all active:scale-[0.98]"
          onClick={() => onNavigate(Screen.DECK_VIEW)}
        >
          <Icon name="upload_file" size={20} />
          <span className="truncate">Import CSV</span>
        </button>
      </div>

      {/* Subheader / Stats */}
      <div className="px-6 py-4 flex items-center justify-between text-sm text-slate-500 dark:text-slate-400 font-medium">
        <span>Your Libraries</span>
        <span>{DECKS.length} Decks • {DECKS.reduce((acc, deck) => acc + deck.count, 0)} Words</span>
      </div>

      {/* Deck List */}
      <div className="flex flex-col gap-4 px-6 pb-6">
        {DECKS.map((deck) => (
          <div 
            key={deck.id}
            onClick={() => onNavigate(Screen.DECK_VIEW)}
            className="group relative flex flex-col gap-3 rounded-xl bg-white dark:bg-slate-800 p-4 shadow-sm border border-slate-100 dark:border-slate-700/50 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex justify-between items-start gap-4">
              <div className="flex items-start gap-4 flex-1">
                <div className={`flex items-center justify-center rounded-lg ${deck.colorClass} shrink-0 size-14`}>
                  <Icon name={deck.icon} size={28} />
                </div>
                <div className="flex flex-1 flex-col justify-center">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-slate-900 dark:text-white text-lg font-semibold leading-tight">{deck.title}</p>
                    {deck.isNew && (
                      <span className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">New</span>
                    )}
                    {deck.isReview && (
                      <span className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Review</span>
                    )}
                  </div>
                  <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal mb-1">{deck.subtitle}</p>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500 font-medium">
                    {deck.fromLang === 'German' && <span>🇩🇪 German</span>}
                    {deck.fromLang === 'English' && <span>🇬🇧 English</span>}
                    <Icon name="arrow_forward" size={10} />
                    {deck.toLang === 'German' && <span>🇩🇪 German</span>}
                    {deck.toLang === 'English' && <span>🇬🇧 English</span>}
                    {deck.count > 100 && (
                      <>
                        <span className="mx-1">•</span>
                        <span>{deck.count} words</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <div className="shrink-0 self-center">
                <Icon name="chevron_right" className="text-slate-300 dark:text-slate-600 group-hover:text-primary transition-colors" />
              </div>
            </div>
            {/* Progress Bar */}
            <div className="w-full bg-slate-100 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-1">
              <div 
                className={`h-full rounded-full ${deck.isReview ? 'bg-yellow-400' : 'bg-primary'}`} 
                style={{ width: `${deck.progress}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      {/* Floating Action Button (FAB) */}
      <div className="fixed bottom-24 right-6 z-50">
        <button aria-label="Add new library" className="group flex items-center justify-center size-14 rounded-full bg-primary text-white shadow-lg hover:bg-sky-500 hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200">
          <Icon name="add" size={32} className="group-hover:rotate-90 transition-transform duration-300" />
        </button>
      </div>

      <BottomNav activeScreen={Screen.LIBRARY} onNavigate={onNavigate} />
    </div>
  );
};
