import React from 'react';
import { Screen } from '../types';
import { Icon } from '../components/Icon';
import { BottomNav } from '../components/BottomNav';

interface DashboardProps {
  onNavigate: (screen: Screen) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  return (
    <div className="relative flex h-full min-h-screen w-full flex-col overflow-x-hidden pb-24 bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-md px-4 pt-4 pb-2">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold leading-tight tracking-[-0.015em]">Guten Morgen, Alex!</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-0.5">Ready to learn German?</p>
          </div>
          <button 
            className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            onClick={() => onNavigate(Screen.SETTINGS)}
          >
            <Icon name="settings" />
          </button>
        </div>
      </header>

      <main className="flex flex-col gap-6 p-4">
        {/* Progress Section */}
        <section className="w-full">
          <div className="bg-surface-light dark:bg-surface-dark rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center gap-6">
            <div className="w-full flex justify-between items-center mb-2">
              <h3 className="text-lg font-bold">Today's Goal</h3>
              <span className="px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold">Keep going!</span>
            </div>
            {/* Circular Progress */}
            <div className="relative w-48 h-48 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-[12px] border-slate-100 dark:border-slate-800"></div>
              <div 
                className="absolute inset-0 rounded-full" 
                style={{
                  background: 'conic-gradient(#13a4ec 75%, transparent 75%)',
                  mask: 'radial-gradient(transparent 58%, black 59%)',
                  WebkitMask: 'radial-gradient(transparent 58%, black 59%)'
                }}
              ></div>
              <div className="flex flex-col items-center justify-center z-10">
                <span className="text-4xl font-bold tracking-tight">15</span>
                <span className="text-sm font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-1">of 20 words</span>
              </div>
            </div>
            <div className="text-center max-w-[80%]">
              <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">
                You've reviewed <span className="font-bold text-primary">75%</span> of your daily target. Only 5 more words to go!
              </p>
            </div>
          </div>
        </section>

        {/* Quick Start Card */}
        <section>
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-base font-bold">Continue Learning</h3>
          </div>
          <div className="group relative overflow-hidden rounded-2xl bg-surface-light dark:bg-surface-dark shadow-sm border border-slate-100 dark:border-slate-700 p-4 transition-all hover:shadow-md cursor-pointer"
               onClick={() => onNavigate(Screen.DECK_VIEW)}>
            <div className="flex items-start gap-4">
              <div className="flex-1 flex flex-col gap-3 z-10">
                <div>
                  <span className="inline-block text-xs font-semibold text-primary mb-1 uppercase tracking-wide">Unit 3</span>
                  <h4 className="text-lg font-bold leading-tight">Kitchen Vocabulary</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 line-clamp-2">Nouns and verbs related to cooking and dining.</p>
                </div>
                <button 
                  className="flex items-center gap-2 bg-primary hover:bg-sky-500 text-white text-sm font-bold py-2 px-4 rounded-lg w-fit transition-colors mt-1 shadow-sm shadow-primary/30"
                  onClick={(e) => { e.stopPropagation(); onNavigate(Screen.FLASHCARD); }}
                >
                  <Icon name="play_arrow" size={20} />
                  <span>Resume</span>
                </button>
              </div>
              <div 
                className="w-24 h-24 sm:w-32 sm:h-32 rounded-xl bg-slate-100 dark:bg-slate-800 flex-shrink-0 bg-cover bg-center self-center"
                style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuChDkVTBX6rJwy9q7Mwoeg3jmjQaY8UgH_X4VpnDYOK4Lre6nLL7kUUARzJxaoMan96POIGd747PwylsVWq4TsyWB1Eh0Koz1UFowAWDdpkFO4ETOMUeHSEZZ-lK19FdMbpizH7sLo_y7yzyUIcw-VBmgF6lr11P_ec5v96Ry2-Fr2jkATn-JMLerZ1gFI2pz5NVS0-YkP91NTGE9yd3QFuqoqGvnqIw3WrRrKFfMu6T2I0lyC4kcmVJDLBuIQmO3l5wShDq02QzUn1")' }}
              ></div>
            </div>
          </div>
        </section>

        {/* Stats Grid */}
        <section>
          <div className="grid grid-cols-2 gap-4">
            <div 
              className="bg-surface-light dark:bg-surface-dark p-4 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex flex-col items-start gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              onClick={() => onNavigate(Screen.STATS)}
            >
              <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg text-orange-500 dark:text-orange-400">
                <Icon name="local_fire_department" />
              </div>
              <div>
                <h4 className="text-2xl font-bold">12</h4>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">Day Streak</p>
              </div>
            </div>
            
            <div 
               className="bg-surface-light dark:bg-surface-dark p-4 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex flex-col items-start gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
               onClick={() => onNavigate(Screen.WEAK_WORDS)}
            >
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg text-green-600 dark:text-green-400">
                <Icon name="school" />
              </div>
              <div>
                <h4 className="text-2xl font-bold">145</h4>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">Words Mastered</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <BottomNav activeScreen={Screen.DASHBOARD} onNavigate={onNavigate} />
    </div>
  );
};
