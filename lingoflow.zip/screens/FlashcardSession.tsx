import React, { useState } from 'react';
import { Screen, Word } from '../types';
import { Icon } from '../components/Icon';
import { speak } from '../utils/speech';

interface FlashcardSessionProps {
  onNavigate: (screen: Screen) => void;
  words: Word[];
}

export const FlashcardSession: React.FC<FlashcardSessionProps> = ({ onNavigate, words }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const currentWord = words[currentIndex] || { original: '', translated: '', type: '' };

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
        if (currentIndex < words.length - 1) {
            setCurrentIndex(prev => prev + 1);
        } else {
            // Loop back or finish
            setCurrentIndex(0);
        }
    }, 200);
  };

  const handleSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();
    speak(currentWord.original);
  };

  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 flex flex-col h-screen overflow-hidden antialiased">
      {/* Top App Bar */}
      <header className="flex items-center justify-between p-4 pt-6 pb-2 bg-background-light dark:bg-background-dark z-10">
        <button 
          onClick={() => onNavigate(Screen.DECK_VIEW)}
          className="flex items-center justify-center size-10 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-900 dark:text-white transition-colors"
        >
          <Icon name="close" size={28} />
        </button>
        <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-500 dark:text-slate-400">German Basics</h2>
        <button 
            className="flex items-center justify-center size-10 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-900 dark:text-white transition-colors"
            onClick={() => onNavigate(Screen.SETTINGS)}
        >
          <Icon name="settings" size={24} />
        </button>
      </header>

      {/* Progress Section */}
      <div className="px-6 py-2">
        <div className="flex justify-between items-end mb-2">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Daily Goal</span>
          <span className="text-sm font-bold text-primary">{currentIndex + 1}/{words.length}</span>
        </div>
        <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary rounded-full transition-all duration-300" 
            style={{ width: `${((currentIndex + 1) / words.length) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Main Content: Flashcard Area */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 py-4 perspective-1000 w-full max-w-md mx-auto">
        {/* Card Container */}
        <div 
          className={`relative w-full h-full max-h-[500px] group cursor-pointer transition-transform duration-500 transform-style-3d shadow-xl dark:shadow-none rounded-2xl ${isFlipped ? 'rotate-y-180' : ''}`}
          onClick={() => setIsFlipped(!isFlipped)}
        >
          {/* Front of Card */}
          <div className="absolute inset-0 w-full h-full bg-white dark:bg-slate-800 rounded-2xl p-6 flex flex-col items-center justify-between backface-hidden shadow-sm border border-slate-100 dark:border-slate-700">
            {/* Image/Visual Context */}
            <div className="w-full h-40 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-900 relative">
               <div className="w-full h-full flex items-center justify-center bg-slate-100 dark:bg-slate-900">
                  <span className="text-6xl select-none">🇩🇪</span>
               </div>
              <div className="absolute top-2 right-2 bg-black/20 backdrop-blur-sm text-white text-xs font-bold px-2 py-1 rounded">{currentWord.type}</div>
            </div>
            
            {/* Word Content */}
            <div className="flex-1 flex flex-col items-center justify-center gap-4 w-full">
              <h1 className="text-4xl font-bold text-center text-slate-900 dark:text-white tracking-tight">{currentWord.original}</h1>
              <button 
                className="flex items-center justify-center size-14 rounded-full bg-primary/10 text-primary hover:bg-primary/20 active:scale-95 transition-all mt-2 shadow-sm border border-primary/10"
                onClick={handleSpeak}
              >
                <Icon name="volume_up" size={32} />
              </button>
              <p className="text-sm text-slate-400 dark:text-slate-500 font-medium mt-4">German • {currentWord.type}</p>
            </div>

            {/* Hint */}
            <div className="w-full text-center py-2 border-t border-slate-100 dark:border-slate-700">
              <p className="text-primary text-sm font-medium flex items-center justify-center gap-2">
                <Icon name="touch_app" size={18} />
                Tap to flip
              </p>
            </div>
          </div>

          {/* Back of Card */}
          <div className="absolute inset-0 w-full h-full bg-white dark:bg-slate-800 rounded-2xl p-6 flex flex-col items-center justify-between backface-hidden rotate-y-180 shadow-sm border border-slate-100 dark:border-slate-700">
             <div className="w-full h-40 rounded-xl bg-slate-50 dark:bg-slate-900 flex items-center justify-center relative">
                <span className="text-6xl select-none">🇬🇧</span>
             </div>
             <div className="flex-1 flex flex-col items-center justify-center gap-2 w-full">
              <h2 className="text-xl text-slate-400 dark:text-slate-500 font-medium">English Translation</h2>
              <h1 className="text-4xl font-bold text-center text-slate-900 dark:text-white tracking-tight mt-2">{currentWord.translated}</h1>
             </div>
             <div className="w-full text-center py-2 border-t border-slate-100 dark:border-slate-700">
              <p className="text-primary text-sm font-medium flex items-center justify-center gap-2">
                <Icon name="touch_app" size={18} />
                Tap to flip back
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Controls */}
      <footer className="p-6 pb-8 bg-background-light dark:bg-background-dark w-full max-w-md mx-auto">
        <div className="grid grid-cols-3 gap-4">
          <button 
            onClick={handleNext}
            className="flex flex-col items-center justify-center gap-1 h-16 rounded-xl bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 font-bold text-base hover:brightness-95 active:scale-95 transition-all border border-rose-200 dark:border-rose-800/50"
          >
            <span>Hard</span>
            <span className="text-[10px] font-normal opacity-80">Again in 1m</span>
          </button>
          
          <button 
             onClick={handleNext}
             className="flex flex-col items-center justify-center gap-1 h-16 rounded-xl bg-primary text-white font-bold text-base shadow-lg shadow-primary/30 hover:brightness-110 active:scale-95 transition-all"
          >
            <span>Good</span>
            <span className="text-[10px] font-normal opacity-90">10 mins</span>
          </button>
          
          <button 
             onClick={handleNext}
             className="flex flex-col items-center justify-center gap-1 h-16 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 font-bold text-base hover:brightness-95 active:scale-95 transition-all border border-emerald-200 dark:border-emerald-800/50"
          >
            <span>Easy</span>
            <span className="text-[10px] font-normal opacity-80">4 days</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
